require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');
const blogRoutes = require('./routes/blogs');
const commentRoutes = require('./routes/comments');
const adminRoutes = require('./routes/admin');

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));

const PORT = process.env.PORT || 5000;

if (!process.env.MONGO_URI) {
  console.warn('Warning: MONGO_URI not set - please set it in .env');
} else {
  connectDB(process.env.MONGO_URI);
}

// routes
app.use('/api/auth', authRoutes);
app.use('/api/auth', adminRoutes); // admin endpoints (list users)
app.use('/api/blogs', blogRoutes);
app.use('/api/comments', commentRoutes);

app.get('/', (req, res) => res.send('Blog API running'));

app.listen(PORT, () => console.log('Server running on', PORT));
