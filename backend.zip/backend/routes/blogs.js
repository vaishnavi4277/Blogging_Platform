const express = require('express');
const router = express.Router();
const Blog = require('../models/Blog');
const { protect, admin } = require('../middleware/auth');

// GET /api/blogs?search=...&tag=...
router.get('/', async (req, res) => {
  try {
    const { search, tag } = req.query;
    let filter = {};
    if (search) filter.$or = [{ title: new RegExp(search, 'i') }, { content: new RegExp(search, 'i') }];
    if (tag) filter.tags = tag;
    const blogs = await Blog.find(filter).populate('author', 'name email').sort({ createdAt: -1});
    res.json(blogs);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/blogs/:id
router.get('/:id', async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id).populate('author', 'name email');
    if (!blog) return res.status(404).json({ message: 'Not found' });
    res.json(blog);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/blogs (protected)
router.post('/', protect, async (req, res) => {
  try {
    const { title, content, image, tags, category } = req.body;
    const blog = await Blog.create({
      title, content, image, tags: tags || [], category, author: req.user._id
    });
    res.json(blog);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// PUT /api/blogs/:id
router.put('/:id', protect, async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: 'Not found' });
    if (blog.author.toString() !== req.user._id.toString() && req.user.role !== 'admin')
      return res.status(403).json({ message: 'Forbidden' });
    const { title, content, image, tags, category } = req.body;
    blog.title = title ?? blog.title;
    blog.content = content ?? blog.content;
    blog.image = image ?? blog.image;
    blog.tags = tags ?? blog.tags;
    blog.category = category ?? blog.category;
    await blog.save();
    res.json(blog);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// DELETE /api/blogs/:id
router.delete('/:id', protect, async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: 'Not found' });
    if (blog.author.toString() !== req.user._id.toString() && req.user.role !== 'admin')
      return res.status(403).json({ message: 'Forbidden' });
    await blog.deleteOne();
    res.json({ message: 'Deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/blogs/:id/like
router.post('/:id/like', protect, async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: 'Not found' });
    const idx = blog.likes.findIndex(l => l.toString() === req.user._id.toString());
    if (idx === -1) blog.likes.push(req.user._id);
    else blog.likes.splice(idx, 1);
    await blog.save();
    res.json({ likes: blog.likes.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/blogs/user/:userId
router.get('/user/:userId', async (req, res) => {
  try {
    const blogs = await Blog.find({ author: req.params.userId }).populate('author','name');
    res.json(blogs);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
